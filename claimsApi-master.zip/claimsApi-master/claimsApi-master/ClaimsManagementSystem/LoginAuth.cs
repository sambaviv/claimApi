﻿using ClaimsManagementSystem.Model;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsManagementSystem
{
    public class LoginAuth
    {
        
        public int Login(Admin info)
        {
           
            int result = 0;
            using (IDbConnection db = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DB\data\database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                string encrpytPassword = EncryptString(info.Password);
                var sql = "Select count(*) from admin where Name = @userName and Password = @password";
                List<int> admin = db.Query<int>(sql, new {userName=info.Name, Password=encrpytPassword}).ToList();

                foreach (var ad in admin)
                {
                    if (ad==1)
                    {
                        result = 1;
                    }
                    
                }
                return result;
            }
        }


        public string EncryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }

    }
}
