﻿using ClaimsManagementSystem.Model;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsManagementSystem
{
    public class ClaimProcess
    {
        public List<ClaimDetails> DisplayClaimDetails()
        {
            using (IDbConnection db = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DB\data\database.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                List<ClaimDetails> claim = db.Query<ClaimDetails>
                    ("select pl.number as PolicyNumber, cu.name as CustomerName, " +
                    "cl.number as ClaimNumber, cl.amount as ClaimAmount, cl.raised_date " +
                    "as ClaimRaisedDate, cl.remarks as ClaimRemarks from policy pl join " +
                    "customer_policy cp on pl.id = cp.policy_id join customer cu on " +
                    "cu.id = cp.customer_id join claim cl on cl.customer_policy_id = cp.id"
                    ).ToList();
                return claim;
            }
        }

        public int AddClaimDetails(string Name, string PolicyNumber,int ClaimNumber, double ClaimAmount, DateTime ClaimRaisedDate, String ClaimRemarks, String ClaimDocument)
        {
            using (IDbConnection db = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DB\data\database.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                string sql = "insert into customer_policy(customer_id,policy_id) " +
                    "select c.id as Id, p.id as Id from customer c, policy p " +
                    "where c.name = @name and p.number = @policyNumber;" +
                    "insert into claim(number, amount, raised_date, remarks, document, customer_policy_id) " +
                    "select @claimNumber as ClaimNumber, @amount as ClaimAmount," +
                    "@raisedDate as ClaimRaisedDate, @remarks as ClaimRemarks, " +
                    "@document as ClaimDocument, cp.id as CustomerPolicyId " +
                    "from customer_policy cp where id=@@IDENTITY";

                 int result = db.Execute(sql, new { name = Name, policyNumber = PolicyNumber, 
                     claimNumber = ClaimNumber, amount = ClaimAmount, raisedDate = ClaimRaisedDate, 
                    remarks = ClaimRemarks, document = ClaimDocument });
                return result;
            }
        }

        public int UpdateClaimDetails(int ClaimNumber, double ClaimAmount, string ClaimRemarks)
        {
            using (IDbConnection db = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DB\data\database.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                string sql = "update claim set amount=@ClaimAmount, remarks=@ClaimRemarks where number = @ClaimNumber";
                int result = db.Execute(sql, new{ ClaimNumber = ClaimNumber, ClaimAmount = ClaimAmount, ClaimRemarks = ClaimRemarks });
                return result;
            }
        }
    }
}
