﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ClaimsManagementSystem.Model;

namespace ClaimsManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClaimController : Controller
    {

        [HttpGet("ViewClaim")]
        public ActionResult<List<ClaimDetails>> GetClaimDetails()
        {
            Service service = new Service();
            List<ClaimDetails> claimDetails = service.DisplayClaimDetails();
            return Ok(claimDetails);
        }


        [HttpPost("AddClaim")]
        public ActionResult<int> Post(string Name, string PolicyNumber, int ClaimNumber, double ClaimAmount, DateTime ClaimRaisedDate, String ClaimRemarks, String ClaimDocument)
        {
            Service service = new Service();
            int status = service.AddClaimDetails(Name, PolicyNumber, ClaimNumber, ClaimAmount, ClaimRaisedDate, ClaimRemarks, ClaimDocument);
            return Ok(status);
        }


        [HttpPut("{ClaimNumber}")]
        public ActionResult<int> Put(int ClaimNumber, double ClaimAmount, string ClaimRemarks)
        {
            Service service = new Service();
            int status = service.UpdateClaimDetails(ClaimNumber, ClaimAmount, ClaimRemarks);
            return Ok(status);
        }


    }
}