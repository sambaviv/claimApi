﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClaimsManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        [HttpPost("AddCustomer")]
        public void Post(String name, String gender, DateTime dateOfBirth, long phoneNumber, string email, string address)
        {
            Service service = new Service();
            int result = service.AddCustomer(name, gender, dateOfBirth, phoneNumber, email, address);
        }
    }
}