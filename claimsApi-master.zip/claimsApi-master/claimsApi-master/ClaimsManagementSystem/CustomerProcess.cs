﻿using ClaimsManagementSystem.Model;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
namespace ClaimsManagementSystem
{
    public class CustomerProcess
    {
        public int AddCustomer(String Name, String Gender, DateTime DateOfBirth, long PhoneNumber, string Email, string Address)
        {
            using (IDbConnection db =
                 new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\DB\data\database.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                string sql = "insert into customer values(@name, @gender, @dateOfBirth, @phoneNumber, @email, @address)";
                int result = db.Execute(sql, new { name = Name, gender= Gender, dateOfBirth = DateOfBirth, phoneNumber = PhoneNumber, email = Email, address=Address });
                return result;
            }
        }
    }
}
