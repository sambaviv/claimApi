﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClaimsManagementSystem.Model;

namespace ClaimsManagementSystem
{
    public class Service
    {
        //login

        public int Login(Admin info)
        {
            LoginAuth lau = new LoginAuth();
            return lau.Login(info);
        }

        //policy

        public int AddPolicy(String PolicyNumber, String Description)
        {
            PolicyProcess policyProcess = new PolicyProcess();
            return policyProcess.AddPolicy(PolicyNumber, Description);

        }

        //customer
        public int AddCustomer(String Name, String Gender, DateTime DateOfBirth, long PhoneNumber, string Email, string Address)
        {
            CustomerProcess customerProcess = new CustomerProcess();
            return customerProcess.AddCustomer(Name, Gender, DateOfBirth, PhoneNumber, Email, Address);
        }

        //claim

        public List<ClaimDetails> DisplayClaimDetails()
        {
            ClaimProcess claimProcess = new ClaimProcess();
            return claimProcess.DisplayClaimDetails();

        }
        public int AddClaimDetails(string Name, string PolicyNumber, int ClaimNumber, double ClaimAmount, DateTime ClaimRaisedDate, String ClaimRemarks, String ClaimDocument)
        {
            ClaimProcess claimProcess = new ClaimProcess();
            return claimProcess.AddClaimDetails(Name, PolicyNumber, ClaimNumber, ClaimAmount, ClaimRaisedDate, ClaimRemarks, ClaimDocument);
        }

        public int UpdateClaimDetails(int ClaimNumber, double ClaimAmount, String ClaimRemarks)
        {
            ClaimProcess claimProcess = new ClaimProcess();
            return claimProcess.UpdateClaimDetails(ClaimNumber, ClaimAmount, ClaimRemarks);
        }
    }
}
