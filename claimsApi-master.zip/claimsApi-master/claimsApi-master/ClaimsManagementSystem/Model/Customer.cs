﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsManagementSystem.Model
{
    public class Customer
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = "";
        public string Gender { get; set; } = "";
        public DateTime DateOfBirth { get; set; } = DateTime.Now;
        public long Phone { get; set; } = 0;
        public string email { get; set; } = "";
        public string address { get; set; } = "";

    }
}
